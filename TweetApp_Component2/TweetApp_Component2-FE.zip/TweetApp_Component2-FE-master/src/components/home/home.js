import React, { Component } from 'react';
import NavigationComponent from '../Navbar/navigation';
import home from '../images/home.jpg';
class HomeComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = { 
            logoURL:home
         }
    }

    componentDidMount(){
        let loginid=sessionStorage.getItem('userLoginId')
        console.log("userLoginId:"+ loginid)
        if(loginid==null){
            alert("Login first,to view home page..:(")
            this.props.history.push('/login')
        }
    }
    render() { 
        return ( 
            <div>
                <NavigationComponent></NavigationComponent>
                <div style={{width:700}} >
                    <div>
                    <h1><img src={this.state.logoURL} style={{width:80,marginBottom:-100}} /></h1>
                     <h3 style={{marginLeft:90,marginTop:10}}><i>Luv2<b>Tweet</b></i></h3>
                     <h4 style={{marginLeft:90}}>Post <b>Here!!</b> Share your <b>Thoughts!!</b></h4>
                     <h4 ><b>Luv2Tweet</b> is an App for registered users to post new tweets</h4>
                    </div>               
                </div>
            </div>
         );
    }
}
 
export default HomeComponent;