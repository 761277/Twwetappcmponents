import React, { Component } from 'react';
import axios from 'axios';
import NavigationComponent from '../Navbar/navigation';
import { Link } from 'react-router-dom';
import like from '../images/like.jpg';

class EditTweetComponent extends Component {
    constructor(props) {
        super(props);
        console.log("this.props:"+this.props)
        console.log("this.props.location.state.tweetId:"+this.props.location.state.tweetId)
       // console.log("this.props.tweetId:"+this.props.tweetId)
        this.state = { 
            id:0,
            tweet:[],
            message:'',
            like:0,
            likeURL:like
         }
    }

    getMessage=(event)=>{
        console.log(event.target.value)
        this.setState({message:event.target.value})
    }

    componentDidMount(){
       // console.log("props:"+ this.props.location.state.currentid)
        axios.get("http://localhost:9511/api/v1/tweet/getTweet/"+ this.props.location.state.tweetId)
        .then(response=>{
            console.log(response)
            this.setState({ tweet: JSON.parse(JSON.stringify(response.data)) })
            console.log(this.state.tweet)
            this.setState({message:this.state.tweet.message})
            console.log(this.state.message)
            
        }).catch(error=>{
            console.log(error)
        })
    }

    onSubmit=(event)=>{
        event.preventDefault()
        this.editTweet()
    }

    editTweet=()=>{
        let editTweetRequestBody={
            "message":this.state.message
        }
        console.log("editTweetRequestBody: "+ editTweetRequestBody)
        let loginid=sessionStorage.getItem('userLoginId')
        console.log("userLoginId:"+ loginid)
        if(loginid=null){
            alert("Login first,to post a tweet..:(")
            this.props.history.push('/login')
        }
        else{
            axios.put("http://localhost:9511/api/v1/tweet/editTweet/"+ this.props.location.state.tweetId,editTweetRequestBody)
            .then(response=>{
                console.log(response)
                console.log(response.config.data)
                this.setState({ tweet: JSON.parse(JSON.stringify(response.data)) })
            console.log(this.state.tweet)
            this.setState({message:this.state.tweet.message})
            console.log(this.state.message)
                localStorage.setItem('tweetId',response.data.tweetId)
                this.props.history.push("/viewTweet")
            }).catch(error=>{
                console.log(error)
            })
        }
    }

    // renderEditTweet=()=>{
    //     console.log("user tweets will be rendered..")
    //     let tweet = {... this.state.tweet} ;
    //     return this.state.tweet.map(tweet=>{
    //         return(
    //             <div key={tweet.tweetId} id={tweet.tweetId}>
                    
    //                 {/* {this.state.tweet.map(element=>{ */}
    //                     <form onSubmit={this.onSubmit(tweet.tweetId)} noValidate>
    //                     <div className="form-group">
    //                         <label>Tweet message</label>
    //                         <textarea id="tweetMsg" name="tweetMsg" rows="4" cols="50" 
    //                         onChange={this.getMessage} value={this.state.message}>
    //                         </textarea>
    //                         {/* <input type="text" contentEditable="true" placeholder="enter text" value={this.state.tweet.message} onChange={this.getMessage}></input> */}
    //                         <button type="submit" className="btn btn-primary btn-lg ">Post</button>
    //                     </div>
    //                 </form>
    //                 })}
    //             </div>
    //         )
    //     //})
    // }

    render() {
        return (
            <div>
                <NavigationComponent></NavigationComponent>
                <h3 align="center">Edit your tweets Here!!!</h3><br></br>
                <form onSubmit={this.onSubmit} noValidate>
                    <div className="form-group">
                        <label>Tweet message</label>
                        <textarea id="tweetMsg" name="tweetMsg" rows="4" cols="50" 
                        onChange={this.getMessage} value={this.state.message}>  
                        </textarea>
                        <div class="row">
                            <div class="column" style={{border:"none"}}>
                            <button onClick={this.updateLike} style={{border:"none",background:"none"}}><img src={this.state.likeURL} style={{width:29}}></img></button>
                            </div>
                            <div class="column">
                            <p>{this.state.tweet.likes}</p>
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary float-right ml-2">Post</button>
                        <Link to='/viewTweet'><button className="btn btn-primary float-right">Cancel</button></Link>
                    </div>
                </form>
            </div>
        );
    }
}
 
export default EditTweetComponent;