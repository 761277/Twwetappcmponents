package com.tweetapp.springbootkafkaconsumerexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKafkaConsumerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
